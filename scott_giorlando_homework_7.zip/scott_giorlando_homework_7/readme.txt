The link to view my website is: http://sgiorlando.github.io/A7/index.html

or you could also use: http://sgiorlando.github.io/A7/sgiorlan_assign7.html

To download all my files you can use: http://sgiorlando.github.io/A7/sgiorlan_assign7.zip